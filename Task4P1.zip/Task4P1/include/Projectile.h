#pragma once
namespace mrsd
{
	struct Projectile
	{
		float x, y;
		float vx, vy;
		float predicted;
	};
}
